<div class="contenedor-flotante">
    <button class="botonF1">
        <i class="fas fa-plus"></i>
    </button>
    <a href="" class="btn1 botonF2">
        <i class="fab fa-whatsapp"></i>
    </a>
    <a href="" class="btn1 botonF3">
        <i class="fab fa-facebook-f"></i>
    </a>
    <a href="" class="btn1 botonF4">
        <i class="fab fa-instagram"></i>
    </a>
</div>