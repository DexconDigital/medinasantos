<?php 
    $url_host = 'http://'.$_SERVER["HTTP_HOST"].'//';
    // $url_host = 'https://'.$_SERVER["HTTP_HOST"].'/';
    $url_total = 'http://'.$_SERVER["HTTP_HOST"].$_SERVER["REQUEST_URI"];

    define('TOKEN', 'WCw8GsTmRcSMenaHMmVj7DyDGxDM9zuZjcWlXnAU-254');

?>